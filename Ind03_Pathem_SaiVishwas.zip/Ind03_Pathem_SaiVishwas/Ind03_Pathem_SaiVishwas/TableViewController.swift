//
//  TableViewController.swift
//  Ind03_Pathem_SaiVishwas
//
//  Created by Sai Vishwas Pathem on 3/29/24.
//

import UIKit

var state_Details:  [(String, String, String)] =
[
    // Defining state_Details with its state name, nick name, and square miles.
    ("Delaware", "The First State", "1,954"),
    ("Alabama", "Yellowhammer State", "50,744"),
    ("Alaska", "The Last Frontier", "571,951"),
    ("Arizona", "The Grand Canyon State", "113,635"),
    ("Arkansas", "The Natural State", "52,068"),
    ("California", "The Golden State", "155,959"),
    ("Colorado", "The Centennial State", "103,718"),
    ("Connecticut", "The Constitution State", "4,845"),
   
    ("Florida", "The Sunshine State", "53,927"),
    ("Georgia", "The Peach State", "57,906"),
    ("Hawaii", "The Aloha State", "6,423"),
    ("Idaho", "The Gem State", "82,747"),
    ("Illinois", "Prairie State", "55,584"),
    ("Indiana", "The Hoosier State", "35,867"),
    ("Iowa", "The Hawkeye State", "55,869"),
    ("Kansas", "The Sunflower State", "81,815"),
    ("Kentucky", "The Bluegrass State", "39,728"),
    ("Louisiana", "The Pelican State", "43,562"),
    ("Maine", "The Pine Tree State", "30,862"),
    ("Maryland", "The Old Line State", "9,774"),
  
    
    ("Massachusetts", "The Bay State", "7,840"),
    ("Michigan", "The Great Lakes State", "56,804"),
    ("Minnesota", "The North Star State", "79,610"),
   
    
    
    
    ("Mississippi", "The Magnolia State", "46,907"),
    ("Missouri", "The Show Me State", "68,886"),
    ("Montana", "The Treasure State", "145,552"),
    ("Nebraska", "The Cornhusker State", "76,872"),
    ("Nevada", "The Silver State", "109,826"),
    ("New Hampshire", "The Granite State", "8,968"),
    ("New Jersey", "The Garden State", "7,417"),
 
    
    
    ("Tennessee", "The Volunteer State", "41,217"),
    ("Texas", "The Lone Star State", "261,797"),
    ("Utah", "The Beehive State", "82,144"),
    ("Vermont", "The Green Mountain State", "9,250"),
    ("Virginia", "The Old Dominion State", "39,594"),
    
    
    
    
    
    
    ("New Mexico", "The Land of Enchantment", "121,356"),
    ("New York", "The Empire State", "47,214"),
    ("North Carolina", "The Tar Heel State", "48,711"),
    ("North Dakota", "The Peace Garden State", "68,976"),
    ("Ohio", "The Buckeye State", "40,948"),
    ("Oklahoma", "The Sooner State", "68,667"),
    ("Oregon", "The Beaver State", "95,997"),
    ("Pennsylvania", "The Keystone State", "44,817"),
    ("Rhode Island", "The Ocean State", "1,045"),
    ("South Carolina", "The Palmetto State", "30,109"),
    ("South Dakota", "Mount Rushmore State", "75,885"),
    
    
    
    
    
    
    
    ("Washington", "The Evergreen State", "66,544"),
    ("West Virginia", "The Mountain State", "24,078"),
    ("Wisconsin", "The Badger State", "54,310"),
    ("Wyoming","The Equality or Cowboy State","97,100")

]


//This is a class that generates a state entity that holds information regarding every state.
// Define a class named State
class State {
// Define properties for the State class
var stateName: String
var stateNickname: String
var stateFlag: UIImage
var stateMap: UIImage
var area: String
    
    //Initialize the State class with values for its properties
    init(stateName:String,stateNickname:String,stateFlag:UIImage,stateMap:UIImage,area:String ){
        self.stateName = stateName
        self.stateNickname = stateNickname
        self.stateFlag = stateFlag
        self.stateMap = stateMap
        self.area = area
    }
}



class TableViewController: UITableViewController { //Defining a TableViewController
    var stateDataCollection = [State]()
    @IBOutlet var stateDetails: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        
        state_Details.sort(by: <)
        // Now we loop through all the given 50 states, create an object of a State and append them in the array
        // Now the getting the stateflag image and statemap image form StateFlags folder
        
// Getting and sorting the names
        for i in 0..<state_Details.count {
            let state: (state: String, nickName : String, area: String) = state_Details[i]
            if let stateFlagImage = UIImage(named: "StateFlags/\(state.state)"),
               let stateMapImage = UIImage(named: "StateFlags/\(state.state)_Map") {
                stateDataCollection.append(State(stateName: state.state, stateNickname: state.nickName, stateFlag: stateFlagImage, stateMap: stateMapImage, area: state.area))
            } else {
                // Handle the case where one or both of the images are not found
                print("One or both of the images for state \(state.state) are missing.")
            }
        }

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return state_Details.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myIdentifier", for: indexPath)

        let cellDetails: (state: String, nickName : String, area : String) = state_Details[indexPath[1]]
        cell.textLabel?.text = cellDetails.state
        cell.detailTextLabel?.text = cellDetails.nickName
        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)  {
        performSegue(withIdentifier: "showDetail", sender: self)

       
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let destinationVC = segue.destination as! ViewController
        destinationVC.stateObject = stateDataCollection[(stateDetails.indexPathForSelectedRow?.row)!]
        
    }
    

}
